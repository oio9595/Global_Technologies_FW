/*
 * TLC59581.c
 *
 *  Created on: Aug 17, 2017
 *      Author: x0268118
 *       *                MSP432P401
 *             ------------------
 *         /|\|                  |
 *          | |                  |
 *          --|RST           GCLK|--P4.3
 *      P3.5--|SIN               |
 *      P3.6--|SCLK              |
 *      P3.7--|XLAT              |
 *            |              SOUT|--P5.2
 *            |                  |
 */
#include <ti/devices/msp432p4xx/driverlib/driverlib.h>

/* Standard Includes */
#include <stdint.h>
#include <stdbool.h>
#include "TLC59581.h"
void Init_TLC59581() // initialize PIN
     {
              GPIO_setAsOutputPin(GPIO_PORT_P3, GPIO_PIN5|GPIO_PIN6|GPIO_PIN7); //P3.5 SIN P3.6 SCLK P3.7 XLAT
              GPIO_setOutputLowOnPin(GPIO_PORT_P3, GPIO_PIN5|GPIO_PIN6|GPIO_PIN7);
              GPIO_setAsInputPin(GPIO_PORT_P5, GPIO_PIN2);   //P5.2 SOUT
    }

void SIN(char i)  //i only 1 or 0
{
    if(i==0)  GPIO_setOutputLowOnPin(GPIO_PORT_P3, GPIO_PIN5);
    else   GPIO_setOutputHighOnPin(GPIO_PORT_P3, GPIO_PIN5);
}
void SCLK(char i) //i only 1 or 0
{
    if(i==0)  GPIO_setOutputLowOnPin(GPIO_PORT_P3, GPIO_PIN6);
        else   GPIO_setOutputHighOnPin(GPIO_PORT_P3, GPIO_PIN6);
}

void LAT(char i) //i only 1 or 0
{
    if(i==0)  GPIO_setOutputLowOnPin(GPIO_PORT_P3, GPIO_PIN7);
        else   GPIO_setOutputHighOnPin(GPIO_PORT_P3, GPIO_PIN7);
}
void GCLK(char i) //i only 1 or 0
{
    if(i==0)
    {
        GPIO_setAsOutputPin(GPIO_PORT_P4, GPIO_PIN3);
        GPIO_setOutputLowOnPin(GPIO_PORT_P4, GPIO_PIN3);
    }
    else  GPIO_setAsPeripheralModuleFunctionOutputPin(GPIO_PORT_P4,GPIO_PIN2|GPIO_PIN3,GPIO_PRIMARY_MODULE_FUNCTION);
}
void SendFC1Data(char BC_sel,int CCR_sel,int CCG_sel,int CCB_sel,char CUE , char PREC_MODE3, char PREC_EN,char LOD_Removal_EN,char SEL_TD0,char LODVTH)
{
    int k;
    char temp1,temp2;
    int  temp3,temp4;
    LAT(1);//GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN7);//XLAT-high
    for(k=14;k>=0;k--)
    {
    SCLK(0);//GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCLK-Low
    __delay_cycles(6); //6/25M=240ns
    SCLK(1);//GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCLK-high
    }
   SCLK(0);// GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCLK-Low
    __delay_cycles(6); //6/25M=240ns
   LAT(0);// GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN7);//XLAT-low
  // Write FC1 command
    for(k=47;k>=44;k--)
    {
         temp1=1<<(k-44);
         temp2=0x09&temp1;
         if(temp2==temp1) SIN(1);//GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=1
         else  SIN(0);//GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=0
         SCLK(0);//  GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCLK-Low
         __delay_cycles(6); //6/25M=240ns
         SCLK(1);//GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCLK-high
    }
    //BC
    for(k=43;k>=41;k--)
    {
        temp1=1<<(k-41);
        temp2=BC_sel&temp1;
        if(temp2==temp1)  SIN(1);//GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=1
        else   SIN(0);//GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=0
        SCLK(0);// GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCLK-Low
        __delay_cycles(6); //6/25M=240ns
        SCLK(1);//GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCLK-high
    }
    //CCR
    for(k=40;k>=32;k--)
    {
        temp3=1<<(k-32);
        temp4=CCR_sel&temp3;
        if(temp4==temp3) SIN(1);//GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=1
         else SIN(0);
        SCLK(0);// GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCLK-Low
         __delay_cycles(6); //6/25M=240ns
        SCLK(1);//GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCLK-high
    }
    //CCG
    for(k=31;k>=23;k--)
    {
        temp3=1<<(k-23);
        temp4=CCG_sel&temp3;
        if(temp4==temp3) SIN(1);//GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=1
        else SIN(0);
        SCLK(0);// GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCLK-Low
        __delay_cycles(6); //6/25M=240ns
        SCLK(1);//GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCLK-high
    }
    //CCB
    for(k=22;k>=14;k--)
    {
        temp3=1<<(k-14);
        temp4=CCB_sel&temp3;
        if(temp4==temp3) SIN(1);//GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=1
        else SIN(0);
        SCLK(0);// GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCLK-Low
        __delay_cycles(6); //6/25M=240ns
        SCLK(1);//GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCLK-high
    }
    //Center Uniformity Enhancement  is 1 or 0
       if(CUE==0) SIN(0);//GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=1
       else SIN(1);
       SCLK(0);// GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCLK-Low
       __delay_cycles(6); //6/25M=240ns
       SCLK(1);//GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCLK-high
   // RSV
       for(k=12;k>=10;k--)
       {
          SIN(0);//GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=0
          SCLK(0);// GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCLK-Low
          __delay_cycles(6); //6/25M=240ns
          SCLK(1);//GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCLK-high
       }
     //PREC_MODE3 is 1 or 0
       if(PREC_MODE3==0) SIN(0);//GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=1
       else SIN(1);
       SCLK(0);// GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCLK-Low
       __delay_cycles(6); //6/25M=240ns
       SCLK(1);//GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCLK-high
     //PREC_EN
       if(PREC_EN==0) SIN(0);//GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=1
       else SIN(1);
       SCLK(0);// GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCLK-Low
       __delay_cycles(6); //6/25M=240ns
       SCLK(1);//GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCLK-high
     //RSV
      for(k=7;k>=5;k--)
      {
          SIN(0);//GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=0
          SCLK(0);// GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCLK-Low
          __delay_cycles(6); //6/25M=240ns
          SCLK(1);//GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCLK-high
       }
      //Write FC1 command
       __delay_cycles(6); //6/25M=240ns
       LAT(1);//GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN7);//XLAT-high
      //LOD_Removal_EN
       if(LOD_Removal_EN==0) SIN(0);//GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=1
       else SIN(1);
       SCLK(0);// GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCLK-Low
       __delay_cycles(6); //6/25M=240ns
       SCLK(1);//GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCLK-high
      //SEL_TDO
       for(k=3;k>=2;k--)
       {
           temp1=1<<(k-2);
           temp2=SEL_TD0&temp1;
           if(temp2==temp1)  SIN(1);//GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=1
           else   SIN(0);//GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=0
           SCLK(0);// GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCLK-Low
           __delay_cycles(6); //6/25M=240ns
           SCLK(1);//GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCLK-high
        }
     //LODVTH
       for(k=1;k>=0;k--)
       {
           temp1=1<<k;
           temp2=LODVTH&temp1;
           if(temp2==temp1)  SIN(1);//GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=1
           else   SIN(0);//GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=0
           SCLK(0);// GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCLK-Low
           __delay_cycles(6); //6/25M=240ns
           SCLK(1);//GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCLK-high
        }
        SCLK(0);//GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCLK-Low
        __delay_cycles(6); //6/25M=240ns
        LAT(0);//GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN7);//XLAT-Low

}
void SendFC2Data(char Reverse_V_R,char Interference_R,char Reverse_V_G,char Interference_G,char Reverse_V_B,char Interference_B,char LGSE1_R , char LGSE1_G, char LGSE1_B,
                 char Enhance,char SEL_PWM,char EMI_REDUCE_R, char EMI_REDUCE_G,char EMI_REDUCE_B,char SEL_PCHG,char SEL_GCLK_EDGE,char PSAVE_ENA,char MAX_LINE)//
{
    int k;
    char temp1,temp2;
    int  temp3,temp4;
  //MSB is 1
   LAT(0);// GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN7);//XLAT-low
    LAT(1);//GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN7);//XLAT-high
    for(k=14;k>=0;k--)
    {
    SIN(1);//GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5 ); //MSB is 1 SDA
    SCLK(0);//GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCLK-Low
    __delay_cycles(6); //6/25M=240ns
    SCLK(1);//GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCLK-high
    }
   LAT(0);// GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN7);//XLAT-low
  // no control data
   for(k=47;k>=44;k--)
   {
        temp1=1<<(k-44);
        temp2=0x06&temp1;
        if(temp2==temp1)  SIN(1);//GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=1
        else  SIN(0);//GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=0
        SCLK(0);//GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCLK-Low
        __delay_cycles(6); //6/25M=240ns
        SCLK(1);//GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCLK-high
       }
    for(k=43;k>=42;k--)
    {
        temp1=1<<(k-42);
        temp2=Reverse_V_R&temp1;
        if(temp2==temp1)  SIN(1);//GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=1
        else  SIN(0);//GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=0
        SCLK(0);//GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCLK-Low
        __delay_cycles(6); //6/25M=240ns
        SCLK(1);//GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCLK-high
    }
    for(k=41;k>=40;k--)
    {
        temp1=1<<(k-40);
        temp2=Interference_R&temp1;
        if(temp2==temp1) SIN(1);// GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=1
        else SIN(0); // GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=0
        SCLK(0);
        __delay_cycles(6); //6/25M=240ns
        SCLK(1);
    }
    for(k=39;k>=38;k--)
    {
        temp1=1<<(k-38);
        temp2=Interference_R&temp1;
        if(temp2==temp1) SIN(1);//GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=1
        else SIN(0);  //GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=0
        SCLK(0);
        __delay_cycles(6); //6/25M=240ns
        SCLK(1);
    }
    for(k=37;k>=36;k--)
    {
        temp3=1<<(k-36);
        temp4=Reverse_V_G&temp3;
        if(temp4==temp3)  SIN(1);
        else SIN(0);
        SCLK(1);
        __delay_cycles(6); //6/25M=240ns
        SCLK(0);
    }
    for(k=35;k>=34;k--)
    {
        temp1=1<<(k-38);
        temp2=Interference_B&temp1;
        if(temp2==temp1) SIN(1);
        else SIN(0);
        SCLK(0);
        __delay_cycles(6); //6/25M=240ns
        SCLK(1);
     }
    for(k=33;k>=32;k--)
    {
        temp3=1<<(k-32);
        temp4=Reverse_V_B&temp3;
        if(temp4==temp3) SIN(1);
        else SIN(0);
        SCLK(0);
         __delay_cycles(6); //6/25M=240ns
        SCLK(1);
    }
    for(k=31;k>=28;k--)
    {
        temp1=1<<(k-28);
        temp2=LGSE1_R&temp1;
        if(temp2==temp1) SIN(1);
        else SIN(0);
        SCLK(0);
        __delay_cycles(6); //6/25M=240ns
        SCLK(1);
     }
    for(k=27;k>=24;k--)
    {
        temp1=1<<(k-24);
        temp2=LGSE1_G&temp1;
        if(temp2==temp1)  SIN(1);
        else SIN(0);
        SCLK(0);
        __delay_cycles(6); //6/25M=240ns
        SCLK(1);
     }
    for(k=23;k>=20;k--)
    {
        temp1=1<<(k-20);
        temp2=LGSE1_B&temp1;
        if(temp2==temp1) SIN(1);
        else SIN(0);
        SCLK(0);
        __delay_cycles(6); //6/25M=240ns
        SCLK(1);
    }
   //RSV_HIGH
    SIN(1);//GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=1
    SCLK(0);//GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCLK-Low
     __delay_cycles(6); //6/25M=240ns
    SCLK(1);//GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCLK-high
  //RSV
    for(k=18;k>=17;k--)
    {
         SIN(0);//GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=0
         SCLK(0);//GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCLK-Low
         __delay_cycles(6); //6/25M=240ns
         SCLK(1);//GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCLK-high
     }
    for(k=16;k>=15;k--)
    {
        temp1=1<<(k-15);
        temp2=Enhance&temp1;
        if(temp2==temp1) SIN(1);
        else SIN(0);
        SCLK(0);
        __delay_cycles(6); //6/25M=240ns
        SCLK(1);
    }
    //SEL_PWM
    if(SEL_PWM==0) SIN(0);
    else SIN(1);
    SCLK(0);
    __delay_cycles(6); //6/25M=240ns
    SCLK(1);
    //EMI_REDUCE_R
    if(EMI_REDUCE_R==0) SIN(0);
    else SIN(1);
    SCLK(0);
    __delay_cycles(6); //6/25M=240ns
    SCLK(1);
    //EMI_REDUCE_G
    if(EMI_REDUCE_G==0) SIN(0);
    else SIN(1);
    SCLK(0);
    __delay_cycles(6); //6/25M=240ns
    SCLK(1);
    //EMI_REDUCE_B
    if(EMI_REDUCE_B==0) SIN(0);
    else SIN(1);
    SCLK(0);
    __delay_cycles(6); //6/25M=240ns
    SCLK(1);
    //RSV
    for(k=10;k>=8;k--)
     {
        SIN(0);//GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=0
        SCLK(0);//GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCLK-Low
        __delay_cycles(6); //6/25M=240ns
        SCLK(1);//GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCLK-high
     }
    // SEL_PCHG
    if(SEL_PCHG==0) SIN(0);
    else SIN(1);
    SCLK(0);
    __delay_cycles(6); //6/25M=240ns
    SCLK(1);
    //SEL_GCLK_EDGE
    if(SEL_GCLK_EDGE==0) SIN(0);
    else SIN(1);
    SCLK(0);
    __delay_cycles(6); //6/25M=240ns
    SCLK(1);
    //PSAVE_ENA
    if(PSAVE_ENA==0)  SIN(0);
    else SIN(1);
    SCLK(0);
    __delay_cycles(6); //6/25M=240ns
    SCLK(1);
    //WRITE FCDATA
    LAT(1);//GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN7);//XLAT-high
    for(k=4;k>=0;k--)
    {
        temp1=1<<(k-0);
        temp2=MAX_LINE&temp1;
        if(temp2==temp1) SIN(1);
        else SIN(0);
        SCLK(0);
        __delay_cycles(6); //6/25M=240ns
        SCLK(1);
    }
      LAT(1); // GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN7);//XLAT-low
}


void SendGsData(int *temp) //
{
    int k,temp1,temp2;
    LAT(0);//GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN7 ); //XLAT-low
    for(k=47;k>=0;k--)
    {
        temp1=1<<(k%16);
        temp2=temp[k/16]&temp1;
        if(temp2==temp1) SIN(1);
        else SIN(0);
        SCLK(0);//GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-Low
        __delay_cycles(6); //6/25M=240ns
        SCLK(1);// GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-high
        if(k==1) LAT(1);
    }
    SCLK(0);// GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-low
    __delay_cycles(6); //Twh1 XLAT high-level pulse width  6/25M=240ns
    LAT(0);//GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN7 ); //XLAT-low
}

void SendVsyncData() //
{
    int k;
    LAT(0);//GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN7 ); //XLAT-low
    for(k=47;k>=3;k--)
    {
        SIN(1);//GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5 );
        SCLK(0);//GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-Low
        __delay_cycles(6); //6/25M=240ns
        SCLK(1);//GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-high
    }
       SCLK(0);//GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-Low

       LAT(1);//GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN7);//XLAT-high
    for(k=2;k>=0;k--)
    {
        SIN(1);//GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5);
        SCLK(0);//GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-Low
        __delay_cycles(6); //6/25M=240ns
        SCLK(1);//GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-high
      }
      SCLK(0);//GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-low

      LAT(0);//GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN7 ); //XLAT-low

}















/*void SendFC1Data(char BC_sel,int CCR_sel,int CCG_sel,int CCB_sel,char CUE , char PREC_MODE3, char PREC_EN,char LOD_Removal_EN,char SEL_TD0,char LODVTH)
{
    int k;
    char temp1,temp2;
    int  temp3,temp4;
    GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN7);//XLAT-high
    for(k=14;k>=0;k--)
    {
    //GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5 ); //MSB is 1 SDA
    GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-Low
    __delay_cycles(6); //6/25M=240ns
    GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-high
    }
    GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-Low
    __delay_cycles(6); //6/25M=240ns
    GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN7);//XLAT-low
  // no control data
    for(k=47;k>=44;k--)
       {
               temp1=1<<(k-44);
               temp2=0x09&temp1;
               if(temp2==temp1)
                 {
                   GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=1
                 }
               else
                 {
                   GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=0
                 }
               GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-Low
               __delay_cycles(6); //6/25M=240ns
               GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-high
       }
    for(k=43;k>=41;k--)
    {
        temp1=1<<(k-41);
        temp2=BC_sel&temp1;
               if(temp2==temp1)
                     {
                        GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=1
                      }
                       else
                         {
                           GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=0
                         }
                       GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-Low
                       __delay_cycles(6); //6/25M=240ns
                       GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-high
    }
    for(k=40;k>=32;k--)
    {
        temp3=1<<(k-32);
        temp4=CCR_sel&temp3;
               if(temp4==temp3)
                     {
                        GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=1
                      }
                       else
                         {
                           GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=0
                         }
                       GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-Low
                       __delay_cycles(6); //6/25M=240ns
                       GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-high
    }
    for(k=31;k>=23;k--)
    {
        temp3=1<<(k-23);
        temp4=CCG_sel&temp3;
               if(temp4==temp3)
                     {
                        GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=1
                      }
                       else
                         {
                           GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=0
                         }
                       GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-Low
                       __delay_cycles(6); //6/25M=240ns
                       GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-high
    }
    for(k=22;k>=14;k--)
    {
        temp3=1<<(k-14);
        temp4=CCB_sel&temp3;
               if(temp4==temp3)
                     {
                        GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=1
                      }
                       else
                         {
                           GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=0
                         }
                       GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-Low
                       __delay_cycles(6); //6/25M=240ns
                       GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-high
    }
    //LSDVLT is 1 or 0
       if(CUE==0)
          {GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN5 );}//SDA 0
       else
          {GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5 );}//SDA 1
       GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-Low
       __delay_cycles(6); //6/25M=240ns
       GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-high

       for(k=12;k>=10;k--)
       {
          GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=0
          GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-Low
          __delay_cycles(6); //6/25M=240ns
          GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-high
       }
       //LSDVLT is 1 or 0
           if(PREC_MODE3==0)
              {GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN5 );}//SDA 0
           else
              {GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5 );}//SDA 1
           GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-Low
           __delay_cycles(6); //6/25M=240ns
           GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-high
           if(PREC_EN==0)
              {GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN5 );}//SDA 0
           else
              {GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5 );}//SDA 1
           GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-Low
           __delay_cycles(6); //6/25M=240ns
           GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-high

           for(k=7;k>=5;k--)
           {
              GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=0
              GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-Low
              __delay_cycles(6); //6/25M=240ns
              GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-high
           }

           __delay_cycles(6); //6/25M=240ns
           GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN7);//XLAT-high


           if(LOD_Removal_EN==0)
              {GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN5 );}//SDA 0
           else
              {GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5 );}//SDA 1
           GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-Low
           __delay_cycles(6); //6/25M=240ns
           GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-high

           for(k=3;k>=2;k--)
           {
               temp1=1<<(k-2);
               temp2=SEL_TD0&temp1;
                      if(temp2==temp1)
                            {
                               GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=1
                             }
                              else
                                {
                                  GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=0
                                }
                              GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-Low
                              __delay_cycles(6); //6/25M=240ns
                              GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-high
           }

           for(k=1;k>=0;k--)
           {
               temp1=1<<(k-0);
               temp2=LODVTH&temp1;
                      if(temp2==temp1)
                            {
                               GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=1
                             }
                              else
                                {
                                  GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=0
                                }
                              GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-Low
                              __delay_cycles(6); //6/25M=240ns
                              GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-high
           }
           GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-Low
           __delay_cycles(6); //6/25M=240ns
           GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN7);//XLAT-Low

}
void SendFC2Data(char Reverse_V_R,char Interference_R,char Reverse_V_G,char Interference_G,char Reverse_V_B,char Interference_B,char LGSE1_R , char LGSE1_G, char LGSE1_B,
                 char Enhance,char SEL_PWM,char EMI_REDUCE_R, char EMI_REDUCE_G,char EMI_REDUCE_B,char SEL_PCHG,char SEL_GCLK_EDGE,char PSAVE_ENA,char MAX_LINE)//
{
    int k;
    char temp1,temp2;
    int  temp3,temp4;
  //MSB is 1
    GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN7);//XLAT-low
    GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN7);//XLAT-high
    for(k=14;k>=0;k--)
    {
    GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5 ); //MSB is 1 SDA
    GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-Low
    __delay_cycles(6); //6/25M=240ns
    GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-high
    }
    GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN7);//XLAT-low
  // no control data
    for(k=47;k>=44;k--)
       {
               temp1=1<<(k-44);
               temp2=0x06&temp1;
               if(temp2==temp1)
                 {
                   GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=1
                 }
               else
                 {
                   GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=0
                 }
               GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-Low
               __delay_cycles(6); //6/25M=240ns
               GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-high
       }
    for(k=43;k>=42;k--)
    {
        temp1=1<<(k-42);
        temp2=Reverse_V_R&temp1;
               if(temp2==temp1)
                     {
                        GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=1
                      }
                       else
                         {
                           GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=0
                         }
                       GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-Low
                       __delay_cycles(6); //6/25M=240ns
                       GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-high
    }
    for(k=41;k>=40;k--)
        {
            temp1=1<<(k-40);
            temp2=Interference_R&temp1;
                   if(temp2==temp1)
                         {
                            GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=1
                          }
                           else
                             {
                               GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=0
                             }
                           GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-Low
                           __delay_cycles(6); //6/25M=240ns
                           GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-high
        }
    for(k=39;k>=38;k--)
        {
            temp1=1<<(k-38);
            temp2=Interference_R&temp1;
                   if(temp2==temp1)
                         {
                            GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=1
                          }
                           else
                             {
                               GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=0
                             }
                           GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-Low
                           __delay_cycles(6); //6/25M=240ns
                           GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-high
        }
    for(k=37;k>=36;k--)
    {
        temp3=1<<(k-36);
        temp4=Reverse_V_G&temp3;
               if(temp4==temp3)
                     {
                        GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=1
                      }
                       else
                         {
                           GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=0
                         }
                       GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-Low
                       __delay_cycles(6); //6/25M=240ns
                       GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-high
    }
    for(k=35;k>=34;k--)
        {
            temp1=1<<(k-38);
            temp2=Interference_B&temp1;
                   if(temp2==temp1)
                         {
                            GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=1
                          }
                           else
                             {
                               GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=0
                             }
                           GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-Low
                           __delay_cycles(6); //6/25M=240ns
                           GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-high
        }
    for(k=33;k>=32;k--)
    {
        temp3=1<<(k-32);
        temp4=Reverse_V_B&temp3;
               if(temp4==temp3)
                     {
                        GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=1
                      }
                       else
                         {
                           GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=0
                         }
                       GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-Low
                       __delay_cycles(6); //6/25M=240ns
                       GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-high
    }

    for(k=31;k>=28;k--)
        {
            temp1=1<<(k-28);
            temp2=LGSE1_R&temp1;
                   if(temp2==temp1)
                         {
                            GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=1
                          }
                           else
                             {
                               GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=0
                             }
                           GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-Low
                           __delay_cycles(6); //6/25M=240ns
                           GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-high
        }
    for(k=27;k>=24;k--)
        {
            temp1=1<<(k-24);
            temp2=LGSE1_G&temp1;
                   if(temp2==temp1)
                         {
                            GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=1
                          }
                           else
                             {
                               GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=0
                             }
                           GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-Low
                           __delay_cycles(6); //6/25M=240ns
                           GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-high
        }
    for(k=23;k>=20;k--)
        {
            temp1=1<<(k-20);
            temp2=LGSE1_B&temp1;
                   if(temp2==temp1)
                         {
                            GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=1
                          }
                           else
                             {
                               GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=0
                             }
                           GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-Low
                           __delay_cycles(6); //6/25M=240ns
                           GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-high
        }

    GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=1
    GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-Low
     __delay_cycles(6); //6/25M=240ns
    GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-high

    for(k=18;k>=17;k--)
        {
         GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=0
         GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-Low
         __delay_cycles(6); //6/25M=240ns
         GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-high
        }
    for(k=16;k>=15;k--)
        {
            temp1=1<<(k-15);
            temp2=Enhance&temp1;
                   if(temp2==temp1)
                         {
                            GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=1
                          }
                           else
                             {
                               GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=0
                             }
                           GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-Low
                           __delay_cycles(6); //6/25M=240ns
                           GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-high
        }
              if(SEL_PWM==0)
                  {GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN5 );}//SDA 0
               else
                  {GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5 );}//SDA 1
               GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-Low
               __delay_cycles(6); //6/25M=240ns
               GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-high

               if(EMI_REDUCE_R==0)
                             {GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN5 );}//SDA 0
                          else
                             {GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5 );}//SDA 1
                          GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-Low
                          __delay_cycles(6); //6/25M=240ns
                          GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-high
                          if(EMI_REDUCE_G==0)
                                        {GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN5 );}//SDA 0
                                     else
                                        {GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5 );}//SDA 1
                                     GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-Low
                                     __delay_cycles(6); //6/25M=240ns
                                     GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-high
                                     if(EMI_REDUCE_B==0)
                                                   {GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN5 );}//SDA 0
                                                else
                                                   {GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5 );}//SDA 1
                                                GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-Low
                                                __delay_cycles(6); //6/25M=240ns
                                                GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-high
                for(k=10;k>=8;k--)
                  {
                      GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=0
                      GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-Low
                      __delay_cycles(6); //6/25M=240ns
                      GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-high
                  }
                if(SEL_PCHG==0)
                                 {GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN5 );}//SDA 0
                              else
                                 {GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5 );}//SDA 1
                              GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-Low
                              __delay_cycles(6); //6/25M=240ns
                              GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-high
                if(SEL_GCLK_EDGE==0)
                       {GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN5 );}//SDA 0
                            else
                        {GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5 );}//SDA 1
                        GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-Low
                         __delay_cycles(6); //6/25M=240ns
                        GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-high
                        if(PSAVE_ENA==0)
                               {GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN5 );}//SDA 0
                                    else
                                {GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5 );}//SDA 1
                                GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-Low
                                 __delay_cycles(6); //6/25M=240ns
                                GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-high

    GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN7);//XLAT-high
           for(k=4;k>=0;k--)
           {
               temp1=1<<(k-0);
               temp2=MAX_LINE&temp1;
                      if(temp2==temp1)
                            {
                               GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=1
                             }
                              else
                                {
                                  GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN5); //SDA=0
                                }
                              GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-Low
                              __delay_cycles(6); //6/25M=240ns
                              GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-high
           }

         //  GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN7);//XLAT-high
           GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN7);//XLAT-low

}
void SendGsData(int *temp) //
{
    int k,temp1,temp2;
    GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN7 ); //XLAT-low
    for(k=47;k>=0;k--)
    {

        temp1=1<<(k%16);
        temp2=temp[k/16]&temp1;
        if(temp2==temp1)
           {GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5);} //SIN=1
        else
           {GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN5 );} //SIN=0
        GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-Low
        __delay_cycles(6); //6/25M=240ns
        GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-high
        if(k==1) GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN7);//XLAT-high
    }
   //__delay_cycles(6); //6/25M=240ns
     GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-low
  // __delay_cycles(1); //6/25M=240ns
    //GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN7);//XLAT-high
    __delay_cycles(6); //Twh1 XLAT high-level pulse width  6/25M=240ns
    GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN7 ); //XLAT-low
}
void SendVsyncData() //
{
    int k;
    GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN7 ); //XLAT-low
    for(k=47;k>=3;k--)
    {

           GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5 );
        GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-Low
        __delay_cycles(6); //6/25M=240ns
        GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-high
    }
    GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-Low

    GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN7);//XLAT-high
    for(k=2;k>=0;k--)
      {

           GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN5);
           //  GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN5 );
          GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-Low
          __delay_cycles(6); //6/25M=240ns
          GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-high
      }
    GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6);//SCL-low

    GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN7 ); //XLAT-low

}*/
