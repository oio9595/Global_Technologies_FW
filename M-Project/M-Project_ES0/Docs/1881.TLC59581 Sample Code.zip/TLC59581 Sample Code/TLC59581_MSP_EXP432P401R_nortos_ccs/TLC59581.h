/*
 * TLC59581.h
 *
 *  Created on: Aug 17, 2017
 *      Author: x0268118
 */

#ifndef TLC59581_H_
#define TLC59581_H_
extern void  Init_TLC59581();
extern void  SIN(char i);
extern void  SCLK(char i);
extern void  LAT(char i);
extern void  GCLK(char i);
extern void  SendFC1Data(char BC_sel,int CCR_sel,int CCG_sel,int CCB_sel,char CUE , char PREC_MODE3, char PREC_EN,char LOD_Removal_EN,char SEL_TD0,char LODVTH);
extern void  SendFC2Data(char Reverse_V_R,char Interference_R,char Reverse_V_G,char Interference_G,char Reverse_V_B,char Interference_B,char LGSE1_R , char LGSE1_G, char LGSE1_B,
                        char Enhance,char SEL_PWM,char EMI_REDUCE_R, char EMI_REDUCE_G,char EMI_REDUCE_B,char SEL_PCHG,char SEL_GCLK_EDGE,char PSAVE_ENA,char MAX_LINE);
extern void  SendGsData(int *temp);
extern void SendVsyncData();


#endif /* TLC59581_H_ */
