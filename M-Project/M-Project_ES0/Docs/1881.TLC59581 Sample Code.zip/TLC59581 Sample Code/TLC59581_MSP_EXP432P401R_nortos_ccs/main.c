/* --COPYRIGHT--,BSD
 * Copyright (c) 2017, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * --/COPYRIGHT--*/
/******************************************************************************
 * MSP432 Empty Project
 *
 * Description: An empty project that uses DriverLib
 *
 *                 MSP432P401
 *             ------------------
 *         /|\|                  |
 *          | |                  |
 *          --|RST           GCLK|--P4.3
 *      P3.5--|SIN               |
 *      P3.6--|SCLK              |
 *      P3.7--|XLAT              |
 *            |              SOUT|--P5.2
 *            |                  |
 * Author: 
*******************************************************************************/
/* DriverLib Includes */
#include <ti/devices/msp432p4xx/driverlib/driverlib.h>

/* Standard Includes */
#include <stdint.h>
#include <stdbool.h>
#include "TLC59581.h"

int main(void)
{
     int GS_data[]={1,511,1023};
     int GS_data_0[]={0,0,0};
     int i;
    /* Stop Watchdog  */
     MAP_WDT_A_holdTimer();
    /* Stop Watchdog */
       //MAP_WDT_A_holdTimer();
          /* Setting the DCO Frequency to a non-standard 8.33MHz */
         // MAP_CS_setDCOFrequency(8330000);

          /* Initializing the clock source as follows:
           *      MCLK = MODOSC/4 = 6MHz
           *      ACLK = REFO/2 = 16kHz
           *      HSMCLK = DCO/2 = 1.5Mhz
           *      SMCLK = DCO/4 = 750kHz
           *      BCLK  = REFO = 32kHz
           */
          MAP_CS_initClockSignal(CS_MCLK, CS_MODOSC_SELECT, CS_CLOCK_DIVIDER_2);  //MODOSC:Internal low-power oscillator with 25-MHz typical frequency
          MAP_CS_initClockSignal(CS_ACLK, CS_MODOSC_SELECT, CS_CLOCK_DIVIDER_1);
          MAP_CS_initClockSignal(CS_HSMCLK, CS_DCOCLK_SELECT, CS_CLOCK_DIVIDER_2);
          MAP_CS_initClockSignal(CS_SMCLK, CS_DCOCLK_SELECT, CS_CLOCK_DIVIDER_4);
          MAP_CS_initClockSignal(CS_BCLK, CS_REFOCLK_SELECT, CS_CLOCK_DIVIDER_1);

          //GPIO_setAsOutputPin(GPIO_PORT_P3, GPIO_PIN5|GPIO_PIN6|GPIO_PIN7); //P3.5 SIN P3.6 SCLK P3.7 XLAT
         // GPIO_setOutputLowOnPin(GPIO_PORT_P3, GPIO_PIN5|GPIO_PIN6|GPIO_PIN7);
          //GPIO_setAsInputPin(GPIO_PORT_P5, GPIO_PIN2);   //P5.2 SOUT
          //GCLK(0);
         Init_TLC59581();
        // SendFC1Data(char BC_sel,int CCR_sel,int CCG_sel,int CCB_sel,char CUE , char PREC_MODE3, char PREC_EN,char LOD_Removal_EN,char SEL_TD0,char LODVTH)
         GCLK(1);//GPIO_setAsPeripheralModuleFunctionOutputPin(GPIO_PORT_P4,GPIO_PIN2|GPIO_PIN3,GPIO_PRIMARY_MODULE_FUNCTION);// P4.3->MCLK   P4.2->ACLK
         //SendFC1Data(7,506,506,506,0,0,0,0,1,1);
          for (i=0;i<16;i++)
         {SendGsData(GS_data);}
           SendVsyncData();

}
