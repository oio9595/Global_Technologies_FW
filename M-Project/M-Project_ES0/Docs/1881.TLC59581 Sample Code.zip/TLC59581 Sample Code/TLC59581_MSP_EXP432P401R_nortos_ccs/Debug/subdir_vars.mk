################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
CMD_SRCS += \
../msp432p401r.cmd 

C_SRCS += \
../TLC59581.c \
../main.c \
../system_msp432p401r.c 

C_DEPS += \
./TLC59581.d \
./main.d \
./system_msp432p401r.d 

OBJS += \
./TLC59581.obj \
./main.obj \
./system_msp432p401r.obj 

OBJS__QUOTED += \
"TLC59581.obj" \
"main.obj" \
"system_msp432p401r.obj" 

C_DEPS__QUOTED += \
"TLC59581.d" \
"main.d" \
"system_msp432p401r.d" 

C_SRCS__QUOTED += \
"../TLC59581.c" \
"../main.c" \
"../system_msp432p401r.c" 


